/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50149
Source Host           : 127.0.0.1:3306
Source Database       : qgpractice

Target Server Type    : MYSQL
Target Server Version : 50149
File Encoding         : 65001

Date: 2017-07-17 20:54:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for chatuser
-- ----------------------------
DROP TABLE IF EXISTS `chatuser`;
CREATE TABLE `chatuser` (
  `userId` int(255) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of chatuser
-- ----------------------------
INSERT INTO `chatuser` VALUES ('1', 'Wilders', '452tdjyninFF');
INSERT INTO `chatuser` VALUES ('2', '你的小祖宗', '123456789');
INSERT INTO `chatuser` VALUES ('4', '你的好爸爸', '1314520');
INSERT INTO `chatuser` VALUES ('5', '123146', '1321245646');
INSERT INTO `chatuser` VALUES ('8', 'superMan', '123456789');
INSERT INTO `chatuser` VALUES ('9', '123456789', '123456789');
