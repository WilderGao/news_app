package SERVICE;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 * 将所有客户端包装成一个Map集合
 * Created by Administrator on 2017/7/16.
 */
public class changeMap<K,V> extends HashMap<K,V> {
    //获取所有的Value组成的Set集合
    public Set<V> getValueSet(){
        Set<V> getValueSet = new HashSet<>();
        for (K key:keySet()){
            //将每个key值对应的value放入到set集合中
            getValueSet.add(get(key));
        }
        return getValueSet;
    }
    //每一个socket端口对应着一条流，这条流是不会改变的，通过流来查找对应的用户名
    public K getKey(V value){
        for (K key:keySet()){
            if (get(key).equals(value)&&get(key)==value){
                return key;
            }
        }
        return null;
    }



    //当某个socket退出时,将对应的key和value删除
    public void deleteKey(V value){
        for (K key:keySet()){
            if (get(key).equals(value)){
                remove(key);
                break;
            }
        }
    }

    //重写put方法，判断value值是否为重复
    public V put(K key,V value){
        for (V values:getValueSet()){
            if (values == value&&values.hashCode()==value.hashCode()){
                throw new RuntimeException("不允许含有重复的名称");
            }
        }
        return super.put(key,value);
    }
}