package SERVICE;

import DAO.chatUserDAO;
import MODEL.chatUser;
import UTIL.Sign;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 注册代码
 * Created by Administrator on 2017/7/16.
 */
public class resign {
    private String userName ;
    private String userPassword ;
    private String againPassword;
    private chatUser User;

    public void doResign(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("欢迎来到注册界面");
        System.out.println("请输入您的用户名，不能超过15个字符,不能少于5个字符");
        while (true){
            userName = scanner.nextLine();
            if (userName.length()>15||userName.length()<5){
                System.out.println("输入用户名长度不符合,请重新输入");
                continue;
            }
            else if (chatUserDAO.checkUserExit(userName)== Sign.USERNAME_EXIT){
                System.out.println("用户名存在,请重新输入");
                continue;
            }
            else break;
        }
        System.out.println("请输入您的密码,不能超过20个字符,不能少于6个字符,只能使用字母和数字");
        while (true){
            userPassword = scanner.nextLine();
            Pattern checkPassword= Pattern.compile("^[A-Za-z0-9]{6,20}$");
            Matcher matchPassword=checkPassword.matcher(userPassword);
            if (userPassword.length()>16||userPassword.length()<6){
                System.out.println("密码长度不符合，请重新输入");
                continue;
            }else if(!matchPassword.matches()){
                System.out.println("出现非法字符");
                continue;
            }else
                break;
        }
        System.out.println("请再次输入您的密码");
        while (true){
            againPassword = scanner.nextLine();
            if (!againPassword.equals(userPassword)){
                System.out.println("密码前后不符合，请重新输入");
            }else
                break;
        }

        //将用户信息写入数据库
        User = new chatUser(userName,userPassword);
        chatUserDAO.addUser(User);
    }

    public static void main(String[] args) {
        new resign().doResign();
    }
}
