package SERVICE;

import java.io.IOException;
import java.util.Scanner;

/**
 * 登录主页面
 * Created by Administrator on 2017/7/16.
 */
public class mainPage {
    public static void main(String[] args) {
        System.out.println("欢迎来到多人聊天室,按" + "#1" + "选择注册," + "按#2选择登录");
        Scanner in = new Scanner(System.in);
        String text = null;
        System.out.println("请输入指令");
        while (true) {
            text = in.nextLine();
            if (text.equals("#1")) {
                new resign().doResign();
                System.out.println("注册成功，即将跳转到登录界面");
                try {
                    Thread.sleep(3000);
                }catch (InterruptedException ie){
                    ie.printStackTrace();
                }
                break;
            } else if (text.equals("#2")) {
                break;
            } else {
                System.out.println("指令有误，请重新输入");
                continue;
            }
        }
        chatSocket chatSocket = new chatSocket();
        try {
            chatSocket.init();
            chatSocket.readAndSend();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
