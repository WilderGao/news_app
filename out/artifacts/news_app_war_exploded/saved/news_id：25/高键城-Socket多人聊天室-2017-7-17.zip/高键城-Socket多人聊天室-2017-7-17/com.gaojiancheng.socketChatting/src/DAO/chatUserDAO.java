package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import MODEL.chatUser;
import UTIL.Sign;
import UTIL.connectionUtil;
import com.sun.org.apache.regexp.internal.RE;

/**
 *
 * Created by Administrator on 2017/7/16.
 */
public class chatUserDAO {
    private static Connection conn = null;
    private static PreparedStatement pstmt = null;

    public static int checkUserPassword(chatUser user){
        try {
            conn = connectionUtil.getInstance().getConnection();
            String sql = "select * FROM chatUser WHERE userName = '" + user.getUserName() + "'";
            pstmt = conn.prepareStatement(sql);
            ResultSet resultSet = pstmt.executeQuery();
            if (resultSet.next()) {
                String getPassword = resultSet.getString("password");
                if (getPassword.equals(user.getPassWord()))
                    return Sign.CHECK_SUCCESS;
                else return Sign.USER_PASSWORD_ERROR;
            } else
                return Sign.USERNAME_NOEXIT;
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            try {
                pstmt.close();
                conn.close();
            }catch (SQLException e){
                e.printStackTrace();
            }
        }
        return 0;
    }

    public static int checkUserExit(String userName){
        try {
            conn = connectionUtil.getInstance().getConnection();
            String sql = "select userName FROM chatUser WHERE userName ='" + userName + "'";
            pstmt = conn.prepareStatement(sql);
            ResultSet resultSet = pstmt.executeQuery();
            if (resultSet.next())
                return Sign.USERNAME_EXIT;
            else return Sign.USERNAME_NOEXIT;
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            try {
                pstmt.close();
                conn.close();
            }catch (SQLException ed){
                ed.printStackTrace();
            }
        }
        return 0;
    }

    public static void addUser(chatUser user){
        try {
            conn = connectionUtil.getInstance().getConnection();
            String sql = "INSERT INTO chatUser (userName,password)value(?,?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, user.getUserName());
            pstmt.setString(2, user.getPassWord());

            pstmt.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            try {
                conn.close();
                pstmt.close();
            }catch (SQLException e){
                e.printStackTrace();
            }
        }
    }

}
