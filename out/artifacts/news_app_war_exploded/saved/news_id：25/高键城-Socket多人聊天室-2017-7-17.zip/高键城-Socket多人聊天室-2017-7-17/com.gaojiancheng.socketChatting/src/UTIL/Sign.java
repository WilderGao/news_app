package UTIL;

/**
 * Created by Administrator on 2017/7/16.
 */
public interface Sign {
    int USERNAME_NOEXIT = 0;
    int USER_PASSWORD_ERROR = -1;
    int CHECK_SUCCESS = 1;
    int USERNAME_EXIT = 2;
}
