package UTIL;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 数据库连接池的静态工具类
 * Created by Administrator on 2017/7/16.
 */
public final class connectionUtil {
    private static connectionUtil instance;
    private static ComboPooledDataSource dataSource;

    private   connectionUtil() throws PropertyVetoException{
        dataSource = new ComboPooledDataSource();

        //设置数据库的参数
        dataSource.setUser("root");
        dataSource.setPassword("452tdjyninFF");
        dataSource.setDriverClass("com.mysql.jdbc.Driver");
        dataSource.setJdbcUrl("jdbc:mysql://localhost:3306/qgpractice");
        dataSource.setMinPoolSize(1);//设置最小连接数
        dataSource.setMaxPoolSize(10);
        dataSource.setMaxStatements(50);//最长等待时间
        dataSource.setMaxIdleTime(60);
    }

    //判断只建立一个连接池
    public static final connectionUtil getInstance(){
        if(instance == null){
            try {
                instance = new connectionUtil();
            } catch (PropertyVetoException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return instance;
    }

    //创建连接
    public synchronized final Connection getConnection(){
        Connection conn = null ;
        try {
            //这个getConnection和方法名含义
            conn = dataSource.getConnection();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return conn;
    }

}
