package UTIL;

/**
 * Created by Administrator on 2017/7/16.
 */
public interface CrazyitProtocol {
    String USER_ROUND = "βΓ";
    String MSG_ROUND = "γ";
    String NAME_EXIST = "-1";
    String LOGIN_SUCCESS = "1";
    String PRIVATE_ROUND = "★";
    String RANGE_ROUND ="θ";
    String SPLIT_SIGN = "Ω";
}
