package MODEL;

/**
 * Created by Administrator on 2017/7/16.
 */
public class chatUser {
    private String userName ;
    private String passWord;


    public chatUser(String userName,String passWord){
        this.userName = userName;
        this.passWord = passWord;
    }
    public void setUserName(String userName){
        this.userName = userName;
    }
    public String getUserName(){
        return userName;
    }
    public void setPassWord(String passWord){
        this.passWord = passWord;
    }
    public String getPassWord(){
        return passWord;
    }

}
