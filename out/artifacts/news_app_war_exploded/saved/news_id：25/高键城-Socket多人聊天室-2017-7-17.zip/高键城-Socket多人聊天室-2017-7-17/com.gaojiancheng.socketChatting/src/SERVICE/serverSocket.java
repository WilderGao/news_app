package SERVICE;

import UTIL.CrazyitProtocol;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

/**
 * 服务器端处理页面
 * Created by Administrator on 2017/7/16.
 */
public class serverSocket {
    public static changeMap<String,PrintStream> socketMap = new changeMap<>();

    public static void main(String[] args) throws Exception{
        //服务器端口,开通8888端口号
        ServerSocket serverSocket = new ServerSocket(8888);

        while (true){
            Socket socket = serverSocket.accept();
            //把接收到的socket放到socket数组中
            //socketList.add(socket);
            //开出一条新线程
            new  ServerThread(socket).start();

        }
    }

    public static class ServerThread extends Thread{
        //定义当前线程所处理的socket
        Socket s = null ;
        BufferedReader br = null;
        PrintStream ps = null;
        private ServerThread(Socket socket) throws Exception{
            s = socket;
            br = new BufferedReader(new InputStreamReader(s.getInputStream()));
        }
        public void run() {
            try {
                String connent = null;
                ps = new PrintStream(s.getOutputStream());
                while ((connent = readMethod()) != null) {
                    //首先要判断这是用户登录的用户名，判断是否登录进去
                    if (connent.startsWith(CrazyitProtocol.USER_ROUND)&&connent.endsWith(CrazyitProtocol.USER_ROUND)){
                        //切断之后变成用户名

                        String userName = cutString(connent,CrazyitProtocol.USER_ROUND);

                        //判断用户名是否重复
                        if (serverSocket.socketMap.containsKey(userName)){
                            //登录失败，返回-1，这里试过了还没问题
                            ps.println(CrazyitProtocol.NAME_EXIST);
                        }else {
                            serverSocket.socketMap.put(userName,ps);
                            ps.println(CrazyitProtocol.LOGIN_SUCCESS);
                            for (PrintStream pst: serverSocket.socketMap.getValueSet()){
                                if (pst == ps)
                                    continue;
                                pst.println(userName+"上线啦");
                            }
                        }

                    }//假如是私聊，以@开头并且有名字的
                    else if (connent.startsWith(CrazyitProtocol.PRIVATE_ROUND)&&connent.endsWith(CrazyitProtocol.PRIVATE_ROUND)){
                        String sentence = cutString(connent,CrazyitProtocol.PRIVATE_ROUND);
                        String getInformation[] = sentence.split(CrazyitProtocol.SPLIT_SIGN);
//
                        //发送给单独一条socket
                        //假如私聊自己
                        if (getInformation[0].equals(socketMap.getKey(ps))){
                            ps.println("你傻逼啊，私聊自己！！");
                        }
                        //假如私聊的人不存在
                        else if (socketMap.get(getInformation[0]) == null){
                            ps.println("不存在此用户或者他没有上线");
                        }
                        else {
                            serverSocket.socketMap.get(getInformation[0]).println(serverSocket.socketMap.getKey(ps) + "" +
                                    "悄悄对你说:" + getInformation[1]);
                        }
                    }
                    //离开聊天的指令
                    else if (connent.equals("EXITCHATTING")){
                        for (PrintStream pst : serverSocket.socketMap.getValueSet()){
                            pst.println(socketMap.getKey(ps)+"下线了");
                        }
                        //将他的socket从Map集合中取走
                        socketMap.remove(socketMap.getKey(ps));
                    }
                    else if (connent.equals("ONLINEFRIENDS")){
                        String onlineFriends = "";
                        int Sum = 0;
                        Set<String> memberSet = socketMap.keySet();
                        for (String friends : memberSet){
                            onlineFriends+=friends+" , ";
                            Sum++;
                        }
                        onlineFriends = onlineFriends.substring(0,onlineFriends.length()-3);
                        //把朋友的信息都转换成一条字符串传送到客户端
                        ps.println("共在线"+Sum+"人："+onlineFriends);
                    }
                    //公聊向每个用户发送消息
                    else{
                        String msg = cutString(connent,CrazyitProtocol.MSG_ROUND);
                        for (PrintStream pstream: serverSocket.socketMap.getValueSet()){
                            //设置保存时间
                            Date date = new Date(System.currentTimeMillis());
                            DateFormat df = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss");
                            String dateString = df.format(date);
                            pstream.println(dateString+"\n"+ serverSocket.socketMap.getKey(ps)+"说："+msg+"\n");
                        }

                    }

                }
            }catch (IOException e){
                e.printStackTrace();
            }finally {
                try {
                    if (br != null)
                        br.close();
                    if (ps != null)
                        ps.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }

        }


        //定义读取客户端数据的方法
        private String readMethod(){
            try{
                return br.readLine();
            }catch (IOException e){
                for (PrintStream ps: serverSocket.socketMap.getValueSet()) {
                    //抛出异常说明这个socket已经断开，将它从Map集合中移走
                        serverSocket.socketMap.remove(s);
                }
            }
            return null;
        }

        private String cutString(String connent,String method){
            //切掉头尾的字符串变成聊天语句
            String newContent = connent.substring(method.length(),connent.length()-method.length());
            return  newContent;
        }
    }
}
