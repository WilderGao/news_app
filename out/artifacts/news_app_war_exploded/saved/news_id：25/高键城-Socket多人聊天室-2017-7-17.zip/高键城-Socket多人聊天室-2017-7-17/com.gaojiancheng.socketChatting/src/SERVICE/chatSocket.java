package SERVICE;

import DAO.chatUserDAO;
import MODEL.chatUser;
import UTIL.CrazyitProtocol;
import UTIL.Sign;

import javax.swing.*;
import java.io.*;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 * 客户端处理页面
 * Created by Administrator on 2017/7/16.
 */
public class chatSocket {

    private static  List<String> contentHistory ;
    private BufferedReader br = null;
    private PrintStream printStream = null;
    private BufferedReader brf = null;
    private String userName;
    private String passWord;
    private chatUser user;


    public void init() throws IOException{
        String tip="请输入用户名";

        while (true) {
            java.net.Socket socket = new java.net.Socket("127.0.0.1",8888);
             userName = JOptionPane.showInputDialog(tip);
             passWord = JOptionPane.showInputDialog("请输入密码");
             user = new chatUser(userName,passWord);

            int result = chatUserDAO.checkUserPassword(user);
            if (result == Sign.USER_PASSWORD_ERROR){
                tip = "密码错误，请重新登录";
                continue;
            }
            if (result == Sign.USERNAME_NOEXIT){
                tip="用户不存在，请重新登录";
                continue;
            }
            if (result == Sign.CHECK_SUCCESS) {
                //一个账号登录多次要去验证
                br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                printStream = new PrintStream(socket.getOutputStream());
                printStream.println(CrazyitProtocol.USER_ROUND+userName+CrazyitProtocol.USER_ROUND);
                //查看服务器传回来的结果
                String resultFromServer = br.readLine();
                if (resultFromServer.equals(CrazyitProtocol.NAME_EXIST)){
                    tip="该用户已登录";
                    continue;
                }else {
                    System.out.println("登录成功,"+" STOREHISTORY 可保存聊天记录，EXITCHATTING 可退出群聊 ， ONLINEFRIENDS 可查看在线成员");
                    break;
                }
            }
        }
        new ClintThread(br).start();
    }


    //线程的执行
    public static class ClintThread extends Thread{
        private java.net.Socket s = null ;
        BufferedReader bufferedReader = null;
        public  ClintThread(BufferedReader br) throws IOException {
            // TODO Auto-generated constructor stub
            bufferedReader = br;
        }

        @Override
        public void run() {
            contentHistory = new ArrayList<>();
            // TODO Auto-generated method stub
            String content = null;
            try {
                while((content = bufferedReader.readLine())!=null){
                    System.out.println(content);
                    contentHistory.add(content);
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }

    //发送和接收消息
    public void readAndSend(){
        //保存聊天记录的输出流
        FileWriter storeHistory;
        //brf = new BufferedReader(new InputStreamReader(System.in));
        try {
            String Information = null;
            Scanner sc=new Scanner(System.in);
            while ((Information = sc.nextLine()) != null) {
                if (Information.equals("")){
                    System.out.println("提示：不能输入空的指令");
                }

                else if (Information.equals("STOREHISTORY")){
                    //将聊天记录输出到指定文件中
                    storeHistory = new FileWriter("chatHistory.txt",true);
                    //设置保存的时间
                    Date date = new Date(System.currentTimeMillis());
                    DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd-hh:mm:ss");
                    String dateString = dateFormat.format(date);
                    storeHistory.write(dateString+"   :"+userName+"\r\n");
                    for (String content:contentHistory){
                        storeHistory.write(content+"\r\n");
                        storeHistory.flush();
                    }
                    storeHistory.write("===============================\r\n");
                    storeHistory.close();
                    System.out.println("记录保存成功");
                    //记录保存之后将清理掉整个聊天的List集合
                    contentHistory.clear();
                }
                //假如他的指令是离开聊天室
                else if (Information.equals("EXITCHATTING")){
                    //不用修饰直接发送走，等待服务器反应之后退出socket
                    printStream.println(Information);
                    System.exit(0);
                }
                //假如他的指令是显示在线成员
                else if (Information.equals("ONLINEFRIENDS")){
                    printStream.println(Information);
                }
                else if (Information.indexOf(':') > 0 && Information.startsWith("@")) {
                    //去掉前面的@
                    Information = Information.substring(1);
                    printStream.println(CrazyitProtocol.PRIVATE_ROUND + Information.split(":")[0] +
                            CrazyitProtocol.SPLIT_SIGN + Information.split(":")[1] + CrazyitProtocol.PRIVATE_ROUND);
                } else {
                    printStream.println(CrazyitProtocol.MSG_ROUND + Information + CrazyitProtocol.MSG_ROUND);
                }

            }
        }catch (IOException e){
            System.out.println("出现异常，请重新登录");
            for (String d:contentHistory){
                System.out.println(d);
            }
            System.exit(0);
        }finally {
            try {
                if (br != null)
                    br.close();
                if (printStream != null)
                    printStream.close();
                if (brf != null)
                    brf.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }

}
